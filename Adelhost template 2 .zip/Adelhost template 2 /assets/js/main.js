// Global variables
let mobileMenuOpen = false;
let users = []; // In-memory user storage
let currentUser = null;

// Initialize the website when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeWebsite();
    addScrollEffects();
    addFormValidation();
    initializeDropdowns();
});

// Initialize website functionality
function initializeWebsite() {
    // Add smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (href !== '#') {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });

    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    });

    // Handle escape key to close modals
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            closeAllModals();
        }
    });

    // Close dropdowns when clicking outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.dropdown')) {
            closeAllDropdowns();
        }
    });
}

// Dropdown Functions
function initializeDropdowns() {
    // Initialize dropdown behavior
    document.querySelectorAll('.dropdown').forEach(dropdown => {
        const link = dropdown.querySelector('a');
        
        // Desktop hover behavior
        dropdown.addEventListener('mouseenter', function() {
            if (window.innerWidth > 768) {
                this.classList.add('active');
            }
        });

        dropdown.addEventListener('mouseleave', function() {
            if (window.innerWidth > 768) {
                this.classList.remove('active');
            }
        });
    });
}

function toggleDropdown(element) {
    if (event) {
        event.preventDefault();
    }
    
    const dropdown = element.parentElement;
    const isActive = dropdown.classList.contains('active');
    
    // Close all other dropdowns
    closeAllDropdowns();
    
    // Toggle current dropdown
    if (!isActive) {
        dropdown.classList.add('active');
    }
}

function closeAllDropdowns() {
    document.querySelectorAll('.dropdown.active').forEach(dd => {
        dd.classList.remove('active');
    });
}

// Modal Functions
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
        // Clear form fields when opening
        const form = modal.querySelector('form');
        if (form) {
            form.reset();
        }
    }
    // Close any open dropdowns when opening modal
    closeAllDropdowns();
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
    }
}

function closeAllModals() {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        modal.style.display = 'none';
    });
}

// Mobile Menu Functions
function toggleMobileMenu() {
    const navMenu = document.querySelector('.nav-menu');
    const toggleButton = document.querySelector('.mobile-menu-toggle i');
    
    mobileMenuOpen = !mobileMenuOpen;
    
    if (mobileMenuOpen) {
        navMenu.style.display = 'block';
        navMenu.style.position = 'absolute';
        navMenu.style.top = '100%';
        navMenu.style.left = '0';
        navMenu.style.right = '0';
        navMenu.style.background = 'white';
        navMenu.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
        navMenu.style.padding = '1rem';
        toggleButton.className = 'fas fa-times';
    } else {
        navMenu.style.display = 'none';
        toggleButton.className = 'fas fa-bars';
        closeAllDropdowns();
    }
}

// Form Handling Functions
function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    // Simulate login validation
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
        currentUser = user;
        closeModal('loginModal');
        showNotification(`Welcome back, ${user.name}!`, 'success');
        updateAuthButtons();
    } else {
        showNotification('Invalid email or password', 'error');
    }
}

function handleRegister(event) {
    event.preventDefault();
    
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    // Validation
    if (password !== confirmPassword) {
        showNotification('Passwords do not match', 'error');
        return;
    }
    
    if (password.length < 6) {
        showNotification('Password must be at least 6 characters', 'error');
        return;
    }
    
    // Check if user already exists
    if (users.some(u => u.email === email)) {
        showNotification('Email already registered', 'error');
        return;
    }
    
    // Create new user
    const newUser = {
        id: Date.now(),
        name: name,
        email: email,
        password: password,
        registeredAt: new Date()
    };
    
    users.push(newUser);
    currentUser = newUser;
    
    closeModal('registerModal');
    showNotification(`Welcome to Adelhost, ${name}!`, 'success');
    updateAuthButtons();
}

function updateAuthButtons() {
    const navAuth = document.querySelector('.nav-auth');
    
    if (currentUser) {
        navAuth.innerHTML = `
            <span style="margin-right: 1rem; color: #2c5aa0;">Hello, ${currentUser.name}</span>
            <button class="btn-login" onclick="logout()">Logout</button>
        `;
    } else {
        navAuth.innerHTML = `
            <button class="btn-login" onclick="openModal('loginModal')">Login</button>
        `;
    }
}

function logout() {
    currentUser = null;
    updateAuthButtons();
    showNotification('Logged out successfully', 'success');
}

// Newsletter Subscription
function subscribeNewsletter() {
    const email = document.getElementById('newsletterEmail').value;
    
    if (!email || !isValidEmail(email)) {
        showNotification('Please enter a valid email address', 'error');
        return;
    }
    
    // Simulate subscription
    document.getElementById('newsletterEmail').value = '';
    showNotification('Successfully subscribed to newsletter!', 'success');
}

// Notification System
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notif => notif.remove());
    
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.innerHTML = `
        <i class="fas fa-${getNotificationIcon(type)}"></i>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()" style="background: none; border: none; color: white; margin-left: 10px; cursor: pointer;">×</button>
    `;
    
    // Set notification styles based on type
    const colors = {
        success: '#28a745',
        error: '#dc3545',
        warning: '#ffc107',
        info: '#17a2b8'
    };
    
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${colors[type] || colors.info};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 3000;
        display: flex;
        align-items: center;
        gap: 10px;
        animation: slideInRight 0.3s ease;
        max-width: 300px;
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

function getNotificationIcon(type) {
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    return icons[type] || icons.info;
}

// Newsletter Subscription
function subscribeNewsletter() {
    const email = document.getElementById('newsletterEmail').value;
    
    if (!email || !isValidEmail(email)) {
        console.log('Please enter a valid email address');
        return;
    }
    
    // Simulate subscription
    document.getElementById('newsletterEmail').value = '';
    console.log('Successfully subscribed to newsletter!');
}

// Utility Functions
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Scroll Effects
function addScrollEffects() {
    // Add active navigation highlighting based on scroll position
    window.addEventListener('scroll', function() {
        const sections = document.querySelectorAll('section[id]');
        const navLinks = document.querySelectorAll('.nav-menu a[href^="#"]');
        
        let currentSection = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 100;
            const sectionHeight = section.offsetHeight;
            
            if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
                currentSection = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${currentSection}`) {
                link.classList.add('active');
            }
        });
    });
    
    // Animate elements on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animationPlayState = 'running';
            }
        });
    }, observerOptions);
    
    // Observe feature and pricing cards
    document.querySelectorAll('.feature-card, .pricing-card').forEach(card => {
        card.style.animationPlayState = 'paused';
        observer.observe(card);
    });
}

// Form Validation
function addFormValidation() {
    // Real-time password confirmation validation
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const passwordInput = document.getElementById('registerPassword');
    
    if (confirmPasswordInput && passwordInput) {
        confirmPasswordInput.addEventListener('input', function() {
            if (passwordInput.value !== confirmPasswordInput.value) {
                confirmPasswordInput.setCustomValidity('Passwords do not match');
            } else {
                confirmPasswordInput.setCustomValidity('');
            }
        });
        
        passwordInput.addEventListener('input', function() {
            if (passwordInput.value !== confirmPasswordInput.value) {
                confirmPasswordInput.setCustomValidity('Passwords do not match');
            } else {
                confirmPasswordInput.setCustomValidity('');
            }
        });
    }
}

// Plan Selection Functions
function selectPlan(planName, price) {
    if (!currentUser) {
        showNotification('Please login or register to select a plan', 'warning');
        openModal('loginModal');
        return;
    }
    
    showNotification(`${planName} plan selected! Redirecting to checkout...`, 'success');
    
    // Simulate redirect to checkout
    setTimeout(() => {
        showNotification('Checkout functionality would be implemented here', 'info');
    }, 2000);
}

// Service Functions for modals
function requestWordPressQuote() {
    console.log('WordPress hosting quote request sent!');
    closeModal('wordpressModal');
}



function requestProServicesQuote() {
    if (!currentUser) {
        showNotification('Please login to request a quote', 'warning');
        closeModal('proServicesModal');
        openModal('loginModal');
        return;
    }
    
    showNotification('Professional services quote request sent! Our team will contact you.', 'success');
    closeModal('proServicesModal');
}

// Hero Button Functions
document.addEventListener('DOMContentLoaded', function() {
    const getStartedBtn = document.querySelector('.btn-primary');
    const viewPricingBtn = document.querySelector('.btn-secondary');
    
    if (getStartedBtn) {
        getStartedBtn.addEventListener('click', function() {
            const pricingSection = document.querySelector('#pricing');
            if (pricingSection) {
                pricingSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    }
    
    if (viewPricingBtn) {
        viewPricingBtn.addEventListener('click', function() {
            const pricingSection = document.querySelector('#pricing');
            if (pricingSection) {
                pricingSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    }
});

// Enhanced Navigation
function highlightActiveNavItem() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-menu a[href^="#"]');
    
    window.addEventListener('scroll', () => {
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 120;
            const sectionHeight = section.offsetHeight;
            
            if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });
}

// Initialize navigation highlighting
document.addEventListener('DOMContentLoaded', highlightActiveNavItem);

// Smooth scroll with offset for fixed header
function smoothScrollToSection(sectionId) {
    const section = document.querySelector(sectionId);
    if (section) {
        const offsetTop = section.offsetTop - 100; // Account for fixed header
        window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
        });
    }
}

// Contact Form Handler
function handleContactForm(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const contactData = {
        name: formData.get('name'),
        email: formData.get('email'),
        subject: formData.get('subject'),
        message: formData.get('message')
    };
    
    // Simulate sending contact form
    showNotification('Message sent successfully! We\'ll get back to you soon.', 'success');
    event.target.reset();
}

// Add CSS animations for notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOutRight {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);

// Performance optimization: Debounce function
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Responsive dropdown handling
window.addEventListener('resize', function() {
    if (window.innerWidth > 768) {
        // Reset mobile menu on desktop
        if (mobileMenuOpen) {
            toggleMobileMenu();
        }
    } else {
        // Close all dropdowns on mobile
        closeAllDropdowns();
    }
});

// Add loading states to buttons
function addLoadingState(button, isLoading = true) {
    if (isLoading) {
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
    } else {
        button.disabled = false;
        button.innerHTML = button.getAttribute('data-original-text') || 'Submit';
    }
}

// Error handling for any uncaught errors
window.addEventListener('error', function(event) {
    console.error('JavaScript Error:', event.error);
    showNotification('An unexpected error occurred. Please try again.', 'error');
});

// Export functions for potential external use
window.Adelhost = {
    openModal,
    closeModal,
    showNotification,
    currentUser: () => currentUser,
    toggleDropdown,
    closeAllDropdowns
};


// FAQ Toggle Function
function toggleFAQ(element) {
    const faqItem = element.parentElement;
    const isActive = faqItem.classList.contains('active');
    
    // Close all FAQ items
    document.querySelectorAll('.faq-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Open clicked item if it wasn't active
    if (!isActive) {
        faqItem.classList.add('active');
    }
}